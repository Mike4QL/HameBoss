#include "app_main.h"
#include "dev_HRF.h"
#include "decoder.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <bcm2835.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>

// receive in variable length packet mode, display and resend. Data with swapped first 2 bytes
int main(int argc, char **argv){
	uint32_t sensorId = 0x01;
	uint8_t manufacturerId = MANUF_SENTEC;
	uint8_t productId = PRODUCT_SENTEC_DEFAULT;
	uint8_t encryptId = SEED_PID;
	int option;
	int quiet = 0;
	
	while ((option = getopt(argc, argv, "e:m:p:s:q")) != -1)
	{
		switch(option)
		{
			case 'e':
				encryptId = strtoul(optarg, NULL, 0);
				break;
			case 'm':
				manufacturerId = strtoul(optarg, NULL, 0);
				break;
			case 'p':
				productId = strtoul(optarg, NULL, 0);
				break;
			case 's':
				sensorId = strtoul(optarg, NULL, 0);
				break;
			case 'q':
				quiet = 1;
				break;
			default:
				printf("Syntax: %s [options]\n\n"
					   "\t-e\tEncryption ID to use\n"
					   "\t-m\tManufacturer ID to send\n"
					   "\t-p\tProduct ID to send\n"
					   "\t-s\tSensor ID to send\n"
					   "\t-q\tQuiet (send no comands)\n", argv[0]);
				return 2;
		}
	}
	if (!quiet)
		printf("Sending to %02x:%02x:%06x, encryption %02x\n",
			   manufacturerId, productId, sensorId, encryptId);

	if (!bcm2835_init())
		return 1;

	time_t currentTime;
	time_t monitorControlTime;
	
	// LED INIT
	bcm2835_gpio_fsel(LEDG, BCM2835_GPIO_FSEL_OUTP);			// LED green
	bcm2835_gpio_fsel(LEDR, BCM2835_GPIO_FSEL_OUTP);			// LED red
	bcm2835_gpio_write(LEDG, LOW);
	bcm2835_gpio_write(LEDR, LOW);
	// SPI INIT
	bcm2835_spi_begin();	
	bcm2835_spi_setClockDivider(SPI_CLOCK_DIVIDER_26); 			// 250MHz / 26 = 9.6MHz
	bcm2835_spi_setDataMode(BCM2835_SPI_MODE0); 				// CPOL = 0, CPHA = 0
	bcm2835_spi_chipSelect(BCM2835_SPI_CS1);					// chip select 1

	HRF_config_FSK();
	HRF_wait_for(ADDR_IRQFLAGS1, MASK_MODEREADY, TRUE);			// wait until ready after mode switching
	HRF_clr_fifo();

	monitorControlTime = time(NULL);
	while (1){
		currentTime = time(NULL);
		
		HRF_receive_FSK_msg(encryptId);
		if (send_join_response)
		{
			printf("send JOIN response\n");
			HRF_send_FSK_msg(HRF_make_FSK_msg(join_manu_id, encryptId, join_prod_id, join_sensor_id,
											  2, PARAM_JOIN_RESP, 0), encryptId);
			send_join_response = FALSE;
		}
		if (!quiet && difftime(currentTime, monitorControlTime) > 10.1)
		{
			monitorControlTime = time(NULL);
			static bool switchState = false;
			switchState = !switchState;
			printf("send MONITOR + CONTROL message:\trelay %s\n", switchState ? "ON" : "OFF");
			bcm2835_gpio_write(LEDG, switchState);
			HRF_send_FSK_msg(HRF_make_FSK_msg(manufacturerId, encryptId, productId, sensorId,
											  3, PARAM_ACTUATE_SW, 1, switchState),
							 encryptId);
		}
	}
	bcm2835_spi_end();
	return 0;
}




