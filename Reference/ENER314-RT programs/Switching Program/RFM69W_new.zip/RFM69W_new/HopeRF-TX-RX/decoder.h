#include <stdlib.h>

void seed(uint8_t, uint16_t);
uint8_t decrypt(uint8_t);
int16_t crc(uint8_t const mes[], size_t);

